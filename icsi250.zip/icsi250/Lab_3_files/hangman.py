import random
import string

WORDLIST_FILENAME = "words.txt"


def load_words():
    print("Loading word list from file...")
    # inFile: file
    inFile = open(WORDLIST_FILENAME, 'r')
    # line: string
    line = inFile.readline()
    # wordlist: list of strings
    wordlist = line.split()
    print("  ", len(wordlist), "words loaded.")
    return wordlist



def choose_word(wordlist):
    return random.choice(wordlist)

wordlist = load_words()

def is_word_guessed(secret_word, letters_guessed):
    # FILL IN YOUR CODE HERE AND DELETE "pass"
    for i in secret_word:
        if(i not in letters_guessed):
            return False
    return True


def get_guessed_word(secret_word, letters_guessed):
    ans = ''
    for i in secret_word:
        if(i in letters_guessed):
            ans += i
        else :
            ans += '_ '

    return ans

def make_my_word(secret_word, letters_guessed):
    ans = ''
    for i in secret_word:
        if(i in letters_guessed):
            ans += i
        else :
            ans += '_'

    return ans

def get_available_letters(letters_guessed):
    # FILL IN YOUR CODE HERE AND DELETE "pass"
    letter = 'abcdefghiklmnopqrstuvwxyz'
    res = ''
    for i in letter:
        if(i not in letters_guessed):  
            res += i
    return res 
    


def hangman(secret_word, guesses, letters_guessed, warning_cnt):
    # FILL IN YOUR CODE HERE AND DELETE "pass"
    if(guesses == 0):
        print("Sorry you run out of guesses.\n")
        print("My word was " + str(secret_word))
        return
    print("You have " + str(warning_cnt) + " warnings left.")
    print("You have " + str(guesses) + " guesses left.\n")
    unused_letters = get_available_letters(letters_guessed)
    print("Available letters: " + str(unused_letters))
    letter_guess = str(input("Please guess a letter:"))
    if(letter_guess in letters_guessed):
        warning_cnt -= 1
        if(warning_cnt >= 0):
            print("Oops! You've already guessed that letter. You have " + str(warning_cnt) + " warnings left: " + str(get_guessed_word(secret_word, letters_guessed)) + "\n")
        else :
            print("Oops! You've already guessed that letter. You have no warnings left so you lose one guess: " + str(get_guessed_word(secret_word, letters_guessed)) + "\n")
            guesses -= 1
            warning_cnt = 0
    elif(str.isalpha(letter_guess) == False or str.islower(letter_guess) == False):
        warning_cnt -= 1
        if(warning_cnt >= 0):
            print("Oops! That is not a valid letter. You have " + str(warning_cnt) + " warnings left: " + str(get_guessed_word(secret_word, letters_guessed)) + "\n")
        else:
            print("Oops! That is not a valid letter. You have no warnings left so you lose one guess: " + str(get_guessed_word(secret_word, letters_guessed)) + "\n")
            guesses -= 1
            warning_cnt = 0
    else:
        letters_guessed = letters_guessed + [letter_guess]
    
        if(letter_guess in secret_word):
            print("Good guess: " + str(get_guessed_word(secret_word, letters_guessed)) + "\n")
            if(is_word_guessed(secret_word, letters_guessed)):
                print("\n Congrulations!!! You Won!!!\n")
                points = len(set(secret_word)) * guesses
                print("Your total score for this game is: " + str(points))
                return
        else:
            guesses -= 1
            print("Oops! That letter is not in my word: " + str(get_guessed_word(secret_word, letters_guessed) + "\n"))

    print("------------\n")
    hangman(secret_word, guesses, letters_guessed, warning_cnt)

def match_with_gaps(my_word, other_word):
    for i in range(0,len(my_word)):
        if(my_word[i] != '_'):
            if(other_word[i] != my_word[i]):
                return False
    
    return True

def show_possible_matches(my_word):
    l = len(my_word)
    matches = []
    for word in wordlist:
        if(l == len(word)):
            if(match_with_gaps(my_word, word)):
                matches += [word]

                
    return matches



def hangman_with_hints(secret_word, guesses, letters_guessed, warning_cnt):
    if(guesses == 0):
        print("Sorry you run out of guesses.\n")
        print("My word was " + str(secret_word))
        return
    print("You have " + str(warning_cnt) + " warnings left.") 
    print("You have " + str(guesses) + " guesses left.\n")
    unused_letters = get_available_letters(letters_guessed)
    print("Available letters: " + str(unused_letters))
    letter_guess = str(input("Please guess a letter:"))
    if(letter_guess == '*'):
        possible_ans = show_possible_matches(make_my_word(secret_word, letters_guessed))
        for ans in possible_ans:
            print(str(ans) + " ") 
    elif(letter_guess in letters_guessed):
        warning_cnt -= 1
        if(warning_cnt >= 0):
            print("Oops! You've already guessed that letter. You have " + str(warning_cnt) + " warnings left: " + str(get_guessed_word(secret_word, letters_guessed)) + "\n")
        else :
            print("Oops! You've already guessed that letter. You have no warnings left so you lose one guess: " + str(get_guessed_word(secret_word, letters_guessed)) + "\n")
            guesses -= 1
            warning_cnt = 0
    elif(str.isalpha(letter_guess) == False or str.islower(letter_guess) == False):
        warning_cnt -= 1
        if(warning_cnt >= 0):
            print("Oops! That is not a valid letter. You have " + str(warning_cnt) + " warnings left: " + str(get_guessed_word(secret_word, letters_guessed)) + "\n")
        else:
            print("Oops! That is not a valid letter. You have no warnings left so you lose one guess: " + str(get_guessed_word(secret_word, letters_guessed)) + "\n")
            guesses -= 1
            warning_cnt = 0
    else:
        letters_guessed = letters_guessed + [letter_guess]
    
        if(letter_guess in secret_word):
            print("Good guess: " + str(get_guessed_word(secret_word, letters_guessed)) + "\n")
            if(is_word_guessed(secret_word, letters_guessed)):
                print("\n Congrulations!!! You Won!!!\n")
                points = len(set(secret_word)) * guesses
                print("Your total score for this game is: " + str(points))
                return
        else:
            guesses -= 1
            print("Oops! That letter is not in my word: " + str(get_guessed_word(secret_word, letters_guessed) + "\n"))

    print("------------\n")
    hangman_with_hints(secret_word, guesses, letters_guessed, warning_cnt)





if __name__ == "__main__":
    secret_word = choose_word(wordlist)
    guesses = 6
    letters_guessed = []
    warning_cnt = 3
    # print("I am thinking of a word that is " + str(len(secret_word)) + " letters long.\n")
    # hangman(secret_word, guesses, letters_guessed, warning_cnt)
    secret_word = choose_word(wordlist)
    hangman_with_hints(secret_word, guesses, letters_guessed, warning_cnt)
