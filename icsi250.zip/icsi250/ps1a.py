annual_salary = float(input("Жилийн цалин = "))
portion_saved = float(input("Сарын цалингийн хадгаламжид нэмэх хувь = "))
total_cost = float(input("Мөрөөдлийн байрны тань нийт үнэ = "))
current_savings = 0
portion_down_payment = float(total_cost * 0.25)
months = 0
monthly_salary = float(annual_salary/12)
r = 0.04
while(current_savings < portion_down_payment):
    current_savings += float(monthly_salary*portion_saved) + float(current_savings*r/12)
    months += 1


print("Number of months:" + str(months))