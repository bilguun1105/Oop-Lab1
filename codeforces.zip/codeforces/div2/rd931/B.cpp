#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e9;
int getAns(int n)
{
    int ans = 0;
    ans += n/15;
    n = n%15;
    ans += n/6;
    n = n%6;
    ans += n/3;
    n = n%3;
    ans += n;
    return ans;
    
}
void solve()
{
    int n; 
    cin >> n;
    if(n<10) 
    {
        cout << getAns(n) << endl;
    }
    else if(n<20)
    {
        cout << min(getAns(n), getAns(n-10) + 1) << endl;
    }
    else 
    {
        cout << min(min(getAns(n), getAns(n-10) + 1), getAns(n-20) + 2) << endl;
    }
}   
int main()
{
    int t;
    cin >> t;
    // t = 1;
    while(t--) solve();
}