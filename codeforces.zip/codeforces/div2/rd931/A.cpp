#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e8;
void solve()
{
    int n;
    cin >> n;
    int a[n];
    for(int i=0; i<n; i++) cin >> a[i];
    sort(a, a+n);
    int a1,a2,a3,a4;
    a1 = a[0]; a2 = a[1]; a3 = a[n-1]; a4 = a[n-2];
    int res = abs(a1 - a3) + abs(a2 - a3) + abs(a1 - a4) + abs(a2 - a4);

    cout << res << endl;
}   
int main()
{
    int t;
    cin >> t;
    // t = 1;
    while(t--) solve();
}