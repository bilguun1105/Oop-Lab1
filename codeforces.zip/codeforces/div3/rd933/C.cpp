#include<bits/stdc++.h>
#define ll long long 
using namespace std;
void solve()
{
    int n; 
    cin >> n;
    string s;
    cin >> s;
    set<int> ans;
    for(int i=0; i<n-2; i++)
    {
        string temp = s.substr(i,3);
        if(temp == "map" )
        {
            ans.insert(i+2);
        }
        else if(temp == "pie")
        {
            ans.insert(i);
        }
    }

    cout << ans.size() << endl;
}
int main()
{
    int t;
    cin >> t;
    // t = 1;
    while(t--) solve();
} 