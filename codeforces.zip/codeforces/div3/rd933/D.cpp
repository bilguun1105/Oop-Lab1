#include<bits/stdc++.h>
#define ll long long
#define pii pair<int,int> 
#define pic pair<int,char>
#define F first
#define S second
using namespace std;
set<int> ans;
void move(int n, vector<pic> thr, int id, int x)
{
    if(id == thr.size())
    {
        ans.insert(x);
        return;
    }
    int pos = x;
    while(thr[id].S != '?' && id < thr.size())
    {
        if(thr[id].S ==  '1')
        {
            pos = ((pos - thr[id].F) <= 0) ? (pos + n - thr[id].F) : (pos - thr[id].F);
        }
        else{
            pos = ((pos + thr[id].F) > n) ? (pos + thr[id].F - n) : (pos + thr[id].F);
        }

        id ++;
    }

    if(id == thr.size())
    {
        ans.insert(pos);
        return;
    }
    int pos1;
    pos1 = ((pos - thr[id].F) <= 0) ? (pos + n - thr[id].F) : (pos - thr[id].F);
    move(n,thr, id+1, pos1);
    pos1 = ((pos + thr[id].F) > n) ? (pos + thr[id].F - n) : (pos + thr[id].F);
    move(n,thr, id+1, pos1);
    return;
}
void solve()
{
    int n, m, k;
    cin >> n >> m >> k;
    // DFS?
    vector<pic> thr;
    for(int i=0; i<m; i++)
    {
        int a;
        char c;
        cin >> a >> c;
        thr.push_back(make_pair(a,c));
    }

    move(n, thr, 0, k);

    cout << ans.size() << endl;
    for(auto it : ans )
    {
        cout << it << " ";
    }
    ans.clear();
    cout << endl;

}
int main()
{
    int t;
    cin >> t;
    // t = 1;
    while(t--) solve();
} 