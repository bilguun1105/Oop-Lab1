#include<bits/stdc++.h>
#define ll long long 
using namespace std;
void solve()
{
    int n;
    cin >> n;
    int a[n];
    int sum =0;
    for(int i=0 ;i<n; i++)
    {
        cin >> a[i];
        sum += a[i];
    }
    if(sum % 4 != 0) 
    {
        cout << "NO\n";
        return;
    }

    for(int i=0; i<n-3; i++)
    {
        if(a[i+1] < a[i] * 2) 
        {
            cout << "NO\n";
            return;
        }
        a[i+1] -= 2*a[i];
        a[i+2] -= a[i];
    }

    if(a[n-1] == a[n-3] && a[n-2] == (a[n-1] + a[n-3])) cout << "YES\n";
    else cout << "NO\n";
}
int main()
{
    int t;
    cin >> t;
    // t = 1;
    while(t--) solve();
} 