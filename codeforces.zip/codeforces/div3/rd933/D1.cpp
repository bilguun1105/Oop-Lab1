#include<bits/stdc++.h>
#define ll long long
#define pii pair<int,int> 
#define pic pair<int,char>
#define F first
#define S second
using namespace std;
void solve()
{
    int n, m, k;
    cin >> n >> m >> k;
    // DFS?
    set<int> ans;
    set<int> possible;
    vector<pic> thr;
    for(int i=0; i<m; i++)
    {
        int a;
        char c;
        cin >> a >> c;
        thr.push_back(make_pair(a,c));
    }
    ans.insert(k);
    for(int i=0; i<m; i++)
    {
        int player;
        for(auto j : ans)
        {
            if(thr[i].S == '0')
            {
                player = (j - 1 + thr[i].F)%n + 1;
                possible.insert(player);
            }
            else if(thr[i].S == '1')
            {
                player = (j - thr[i].F - 1 + n)%n + 1;
                possible.insert(player);
            }
            else{
                player = (j - 1 + thr[i].F)%n + 1;
                possible.insert(player);
                player = (j - thr[i].F - 1 + n)%n + 1;
                possible.insert(player);
            }
        }
        ans = possible;
        possible.clear();
    }

    cout << ans.size() << endl;
    for(auto it : ans )
    {
        cout << it << " ";
    }
    ans.clear();
    cout << endl;

}
int main()
{
    int t;
    cin >> t;
    // t = 1;
    while(t--) solve();
} 