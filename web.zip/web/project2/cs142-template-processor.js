"use strict";

class Cs142TemplateProcessor
{
    constructor(template)
    {
        this.template = template;
    }
    fillIn(dictionary)
    {   
        var res = this.template;
        res = res.replace("{{month}}", dictionary.month);
        res = res.replace("{{day}}", dictionary.day);
        res = res.replace("{{year}}", dictionary.year);
        return res;
    }
}
