#include<iostream>
#include<string.h>
using namespace std;
class Employee
{
    public: 
        int Number;
        char Name[20];
        char occupation[10];
        float work_time;
        void scan();
        void print();
        float salary()
        {
            float saly = work_time * 10000;    // tsagiin tsalin 10000
            if(strcmp(occupation,"zahiral") == 0) 
            {
                saly += zahiral_salary();
            } 
            return saly;
        }
        float zahiral_salary()
        {
            if(strcmp(occupation,"zahiral") == 0) 
            {
                return (work_time * 20000); // tsolnii nemegdel 20000
            }
            else return 0;
        }   
        bool add_work_time(float workTime);
};

void Employee :: scan()
{
    cout << "Ajiltnii dugaariig oruulna uu: ";
    cin >> Number;
    cout << "Ajiltnii neriig oruulna uu: ";
    cin >> Name;
    cout << "Ajiltnii alban tushaaliig oruulna uu: ";
    cin >> occupation;
    cout << "Ajiltnii ajillasan tsagiig oruulna uu: ";
    cin >> work_time;
}
void Employee :: print()
{
    cout << "Dugaar:  " << Number << endl <<  "Ner: " << Name << endl << "Alban Tushaal: " << occupation << endl << "Ajillasan tsag: " << work_time << endl;
}

bool Employee :: add_work_time(float workTime)
{
    if(workTime <= 24 && workTime >= 0) return true;
    return false;
}
int main()
{   
    Employee emp[5];

    for(int i=0; i<2; i++)
    {
        emp[i].scan();
    }
    
    for(int i=0; i<2; i++)
    {
        cout << i+1 << " dugeer ajiltan: \n";
        emp[i].print(); 
        cout << "Tsalin: " << emp[i].salary() << endl;
        cout << "Nemeh tsag:";
        float add;
        cin >> add; 
        while(!emp[i].add_work_time(add)) 
        {
            cout << "Aldaatai ogogdol!! Dahin oruulna uu\n";
            cin >> add;
        }
        emp[i].work_time += add;
        cout << "Tsag nemsnii daraah tsalin: " << emp[i].salary() << endl;

        cout << "------------------\n";
    }
}