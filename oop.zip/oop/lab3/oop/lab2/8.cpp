#include<iostream>
using namespace std;
void swap(int *a, int *b)
{
    int * tmp;
    tmp = a;
    a = b;
    b = tmp;
}
main()
{
    int a, b;
    cin >> a >> b;

    cout << "Before Swap: ";
    cout << a << " " << b << endl;
    swap(a, b);

    cout << "After Swap: ";
    cout << a <<" "<< b; 
}