#include<iostream>
using namespace std;
main()
{
    char *p1;
    int *p2;
    double *p3;
    cout<<sizeof(p1)<<endl<<sizeof(p2)<<endl<<sizeof(p3) << endl; // Эдгээр нь харгалзан 8 8 8 гэсэн утгыг хэвлэж байна.
    cout << sizeof(int);
}