#include<iostream>
using namespace std;
void swap(int &a, int &b)
{
    int tmp;
    tmp = a;
    a = b;
    b = tmp;
}
main()
{
    int a, b;
    cin >> a >> b;
    int &first = a;
    int &second = b;
    cout << "Before Swap: ";
    cout << first << " " << second << endl;
    swap(first, second);

    cout << "After Swap: ";
    cout << first <<" "<< second; 
}