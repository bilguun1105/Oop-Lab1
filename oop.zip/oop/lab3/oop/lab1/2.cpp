#include<iostream>
#define pi 3.14     // pi-г 3.14 өөр тохируулсан
using namespace std;
int main()
{
    float r;
    cin >> r;   
    double s;   
    s = pi * r * r; // талбайг тойргийн талбай олдог томъёогоор бодож олсон
    cout << "Toirgiin talbai = " << s;
}