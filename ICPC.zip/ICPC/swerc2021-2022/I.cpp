#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e8;
void solve()
{
    int n,m;
    cin >> n >> m;
    int people[n];
    ll sum = 0;
    for(int i=0; i<n; i++) 
    {
        cin >> people[i]; 
        sum += people[i];
    }
    int pos[m];
    for(int j=0; j<m; j++) cin >> pos[j];
    ll l[n] = {0};
    l[-1] = 0;
    for(int i=0; i<n; i++) 
    {
        l[i] = l[i-1] + people[i]; 
    }

    ll le[m] = {0};
    ll ri[m+1] = {0};

    for(int j=0; j<m; j++)
    {
        int p = pos[j] / 100;
        le[j] = l[p];
        ri[j] = sum - le[j];
    }
    le[-1] = 0;
    ri[m] = 0;
    for(int j=0; j<m; j++)
    {
        le[j] -= le[j-1];
        ri[j] -= ri[j+1];
    }
    
    for(int i=0; i<m; i++)
    {
        cout << le[i] << " " << ri[i] << endl;
    }
}   
int main()
{
    int t;
    // cin >> t;
    t = 1;
    while(t--) solve();
}