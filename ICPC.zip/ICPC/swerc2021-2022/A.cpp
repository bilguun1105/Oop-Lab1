#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e8;
void solve()
{
    int n;
    cin >> n;
    vector<pii> arr;
    for(int i=0; i<n; i++)
    {
        int b, d;
        cin >> b >> d;
        arr.pb(make_pair(d,b));
    }

    sort(arr.begin(), arr.end());

    int lvl = 1;
    int ans = 0;
    int tmp = 0;
    for(int j=1; j<=10; j++)
    {   
        tmp = 0;
        for(int i=0; i<n; i++)
        {
            if(arr[i].first == j) 
            {
                tmp = max(tmp, arr[i].second);
            }
        }
        if(tmp == 0) 
        {
            cout << "MOREPROBLEMS\n";
            return;
        }
        ans += tmp;
    }
    cout << ans << "\n";
}   
int main()
{
    int t;
    cin >> t;
    // t = 1;
    while(t--) solve();
}