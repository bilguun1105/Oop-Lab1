#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e8;
void solve()
{
    int w, l;
    cin >> w >> l;
    int gcd[3];
    gcd[0] = __gcd(w-1,l-1);
    gcd[1] = __gcd(w,l-2);
    gcd[2] = __gcd(w-2,l);
    set<int> ans;
    for(int j=0; j<3; j++)
    {
        int k = sqrt(gcd[j]);
        for(int i=1; i<=k; i++)
        {
            if(gcd[j] % i == 0) 
            {
                ans.insert(i);
                ans.insert(gcd[j]/i);
            }
        }
    }
    if((w-l) % 2 != 0) ans.insert(2);
    cout << ans.size() << " ";

    for(auto i : ans)
    {
        cout << i << " ";
    }
    cout << "\n";
    
}   
int main()
{
    int t;
    cin >> t;
    // t = 1;
    while(t--) solve();
}