#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e8;
// 1 2 3 4 5 6 7 8
// I II III IV V VI VII VIII
void solve()
{
    // IIIIVIV = 344
    // VIVIIII = 44
    string s; 
    cin >> s;
    int n = s.length();
    string ans;
    reverse(s.begin(),s.end());

    for(int i=0; i<n;)
    {
        if(s[i] == 'V')
        {
            i++; 
            if(s[i] == 'V' || i == n)
            {
                ans += '5';
            }
            else{
                ans += '4';
                i++;
            }
        }
        else 
        {
            i++;
            if(i == n) ans += '1';
            else 
            {
                if(s[i] == 'I')
                {       
                    i++;
                    if(i == n) ans += '2';
                    else
                    {
                        if(s[i] == 'I')
                        {
                            i++;
                            if(s[i] == 'I' || i == n) 
                            {
                                ans += '3';
                            }
                            else 
                            {
                                ans += '8';
                                i++;
                            }
                        }
                        else 
                        {
                            ans += '7';
                            i++;
                        }
                    }
                }
                else 
                {
                    ans += '6';
                    i++;
                }
            }
        }
    }
    reverse(ans.begin(), ans.end());
    cout << ans << endl;
}   
int main()
{
    int t;
    cin >> t;
    while(t--) solve();
}