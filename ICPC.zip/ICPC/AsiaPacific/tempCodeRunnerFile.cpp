
            if(chck(res+i) != a[i]) 