#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e8;
void solve()
{
    int n;
    cin >> n;
    int a[n];
    int mx = 0;
    int ind = 0;
    for(int i=0; i<n; i++) 
    {
        cin >> a[i];
    }
    if(n == 1)
    {
        cout << (1LL << a[0]) - 1 << endl;
        return;
    }
    ind = 1;
    for(int i=1; i<n; i++)
    {
        if(a[ind-1] - a[ind] < a[i-1] - a[i]) ind = i; 
    }

    //  max dif;

    ll res = ((1LL << a[ind]) - 1) << (a[ind-1] - a[ind] + 1);

    for(int i=0; i<n; i++)
    {
        if(a[i] != __builtin_popcountll(res - ind + i)) 
        {
            cout << "-1\n";
            return;
        }
    }

    cout << res - ind << endl;
}   
int main()
{
    int t;
    cin >> t;
    // t = 1;
    while(t--) solve();
}