#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e8;
void solve()
{
    int n, m, k;
    cin >> n >> m >> k;
    int ht[n][m];
    string s;
    for(int i=0; i<n; i++)
    {   
        cin >> s;
        for(int j=0; j<m; j++)
        {
            ht[i][j] = s[j] - 'A';
        } 
    }

    vector<pii> ans;

    for(int i=0; i<n-1; i++)
    {
        for(int l = i+1; l<n; l++)
        {
        int cnt = 0;
            for(int j=0; j<m; j++)
            {
                if(ht[i][j] == ht[l][j] && ht[i][j] != -19 ) cnt++;
            }
        if(cnt >= k) 
        {
            ans.pb(make_pair(l,i));
            break;
        }
        }
    }

    if(ans.empty()) 
    {
        cout << "-1\n";
        return;
    }
    sort(ans.begin(), ans.end());

    int l = ans.size();
    int mn = ans[0].first;
    pii res = ans[0];
    for(int i=0; i<l; i++)
    {
        if(mn == ans[i].first)
        {
            if(res.second < ans[i].second) res = ans[i];
        }
        else break;
    }

    cout << res.second + 1 << " " << res.first + 1 << endl;
}   
int main()
{
    int t;
    // cin >> t;
    t = 1;
    while(t--) solve();
}