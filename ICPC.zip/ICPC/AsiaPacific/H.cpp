#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e8;
void solve()
{
    int n;
    cin >> n;
    int O[n] = {0}, I[n] = {0};
    string s;
    for(int i=0; i<n; i++)
    {
        cin >> s;
        for(int j=0; j<s.length(); j++)
        {
            if(s[j] == '0') O[i] ++;
            else I[i] ++;
        }
    }
    bool isO = false, isI = false;
    ll res = 0;
    for(int i=0; i<n; i++)
    {
        if(O[i] > I[i]) 
        {
            res += I[i];
            isI = true;
        }
        else if(O[i] < I[i])
        {
            res += O[i];
            isO = true;
        }
        else 
        {
            res += O[i];
            isO = true;
            isI = true;
        }
    }
    if(res == 0) 
    {
        cout << res << endl;
        return;
    }
    if(isO && isI) 
    {
        cout << res << endl;
        return;
    }
    ll ans;
    if(!isO)
    {   
        ans = res - I[0] + O[0];
        for(int i=0; i<n; i++)
        {
            ans = min(ans, res - I[i] + O[i]);
        }
    }
    else 
    {
        ans = res + I[0] - O[0];
        for(int i=0; i<n; i++)
        {
            ans = min(ans, res + I[i] - O[i]);
        }
    }

    cout << ans << endl;
}   
int main()
{
    int t;
    // cin >> t;
    t = 1;
    while(t--) solve();
}