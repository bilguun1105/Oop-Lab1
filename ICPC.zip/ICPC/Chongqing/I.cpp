#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e9;
const ll mod = 998244353;
ll sum = 0;
int n, m, k;

void solve()
{
    ll a[m];
    int cnt = 0;
    for(int i=0; i<m; i++) 
    {
        cin >> a[i];
    }

    ll sum = 0;
    ll inc = 0;
    sort(a,a+m);
    if(n <= m)
    {
        cout << "0 ";
        for(int i=0; i<n; i++)
        {
            if(a[i] > k) cnt ++;
        }

        cout << cnt << endl;
        return;
    }
    cnt = 0;

    for(int i=0; i<m; i++)
    {
        if(a[i] > k) cnt ++;
        sum += k/a[i];
        if(k%a[i] != 0) inc += 1;
    }

    if(sum >= n) cout << "0 " << cnt << endl;
    else {

        if(sum + inc >= n) 
        {
            cout << "0 ";
            cout << min(inc, n - sum) << endl;
        }
        else 
        {
            cout << n - sum - inc << " " << inc << endl; 
        }
        
    }
}
int main()
{
    cin >> n >> m >> k;
    solve();
}