#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e9;
const ll mod = 998244353;
ll sum = 0;
string s;
//  p will get first max,
void solve()
{
    
}
int main()
{
    cin >> s;
    solve();
}