#include<bits/stdc++.h>
#include<unistd.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e9;
const ll mod = 998244353;
ll sum = 0;
int n;
void solve()
{
    string s[n];
    for(int i=0; i<n; i++) cin >> s[i];

    vector<char> ar;
    int i = 0;
    while()

    cout << "\n";
    
}
int main()
{
   cin >> n;
   solve();
}