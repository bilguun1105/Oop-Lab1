#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e9;
const ll mod = 998244353;
ll sum = 0;
int n, l, r;
void solve()
{
    int a[n];
    for(int i=0; i<n; i++) cin >> a[i];
    int sum[n] = {0};
    sum[0] = a[0];
    for(int i=1; i<n; i++)
    {
        sum[i] = sum[i-1] + a[i]; 
    }
    
    int dp[n];
    l = l-1;
    r = r-1;
    for(int i=0; i<=r; i++)
    {
        if(i < l) dp[i] = 0;
        else dp[i] = sum[i];
    }

    for(int i=r+1; i<n; i++)
    {
        int k = i - r;
        int q = i - l;
        dp[i] = INT_MAX;
        for(int j = k; j<=q; j++)
        {
            if(dp[j] != 0) dp[i] = min(dp[i], dp[j] + sum[i]);
        }
        if(dp[i] == INT_MAX) dp[i] = 0;
    }


    cout << dp[n-1] << endl;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cin >> n >> l >> r;
    solve();
}