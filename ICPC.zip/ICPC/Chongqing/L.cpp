#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e9;
const ll mod = 998244353;
ll sum = 0;
string s;
void solve()
{
    int n;
    cin >> n;
    int dp[n];
    cin >> s;
    
}
int main()
{
   int t;
   cin >> t;
   while(t--) solve();
}