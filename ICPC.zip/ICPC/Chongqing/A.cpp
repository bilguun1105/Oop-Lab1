#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e9;
const ll mod = 998244353;
ll sum = 0;
int n, T;
void get(ll a[], ll t[], int vis[], int ind)
{
    if(ind == n) 
    {
        int cons = 0;
        for(int i=0; i<n; i++)
        {
            if(vis[i] == 0) 
            {
                if(cons + t[i] <= T) 
                {
                    sum = (sum + a[i]) % mod;
                    cons += t[i];
                }
                else return;
            }
        }

        for(int i=0; i<n; i++)
        {
            if(vis[i] == 1)
            {
                if(cons + t[i] <= T)
                {
                    sum = (sum + a[i]) % mod;
                    cons += t[i];
                }
                else return;
            }
        }
        return;
    }

    vis[ind] = 0;
    get(a,t,vis,ind+1);
    vis[ind] = 1;
    get(a,t,vis,ind+1);

}
void solve()
{
    ll a[n];
    int vis[n] = {0};
    ll t[n];
    for(int i=0; i<n; i++) cin >> a[i];

    for(int j=0; j<n; j++) cin >> t[j];


    get(a,t,vis,0);
    cout << sum << endl;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cin >> n >> T;
    solve();
}