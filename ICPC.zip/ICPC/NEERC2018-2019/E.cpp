#include <bits/stdc++.h>
#define pob pop_back
#define pb push_back
using namespace std;
int t;
bool done = false;
bool v[8][8] = {0};
vector<int> path;
void dfs( int current_pos, int movement) {
    if(movement+1 > t) 
    {
        return;
    }
    
    for(int i=0; i<8; i++) {
        if(!v[current_pos/8][i]) {
            v[current_pos/8][i] = 1;
            path.pb((current_pos/8)*8 + i);
            if(movement+1==t && current_pos/8 == 7 && i == 7) {
                done = true;
                return;
            }
            dfs((current_pos/8)*8 + i, movement+1);
            if(done) return;
            path.pop_back();
            v[current_pos/8][i] = 0;
        }
    }
    if(done) return;
    for(int i=0; i<8; i++) {
        if(!v[i][current_pos%8]) {
            v[i][current_pos%8] = 1;
            path.pb(i*8 + current_pos%8);
            if(movement+1==t && i == 7 && current_pos%8 == 7) {
                done = true;
                return;
            }
            dfs(i*8 + current_pos%8, movement+1);
            if(done) return;
            path.pop_back();
            v[i][current_pos%8]= 0;
        }
    }
}

int main() {
 
    cin >> t;
    bool visited[65]={false};
    path.pb(0);
    v[0][0] = 1;
    dfs(0,0);
    for(int i=0; i<path.size(); i++)
    {
        char ans = 'a' + path[i]/8;
        cout << ans;
        cout << path[i]%8 + 1 << " ";
    }
    return 0;
}