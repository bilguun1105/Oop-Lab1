#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define pii pair<int,int>
#define F first
#define S second
using namespace std;
void solve()
{
    int k;
    cin >> k;

    int a[7];
    int rout = 0;
    vector<int> pos;
    for(int i=0; i<7; i++) 
    {
        cin >> a[i];
        rout += a[i];
        if(a[i] == 1)
        {
            pos.pb(i);
        }
    }
    
    ll ans;
    if(rout == 1)
    {
        ans = (k/rout-1) * 7 + 1 ;
        cout << ans << endl;
        return;
    }
    if(k%rout == 0) 
    {
        ans = (k/rout-1)*7;
        k = rout;
    }
    else 
    {
        ans = (k/rout) * 7;
        k = k%rout;
    }
    int dp[rout + 1] = {0};
    for(int i=0; i<rout; i++)
    {
        pos.pb(pos[i] + 7);
    }
    for(int i=1; i<=rout; i++)
    {
        dp[i] = 7;
        int l=0, r=0;
        int cur = 1;
        while(r < pos.size())
        {
            if(cur == i)
            {
                dp[i] = min(dp[i], (pos[r]-pos[l]+1));
                l++;
                r++;
            }
            else 
            {
                r++;
                cur += 1;
            }
        }
    }

    cout << ans + dp[k] << "\n";
}
int main()
{
    int t;
    cin >> t;
    while(t--) solve();
}