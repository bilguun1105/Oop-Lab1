#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define pii pair<int,int>
#define F first
#define S second
using namespace std;
void solve()
{
    int n,k;
    cin >> n >> k;
    int a[n];
    int b[n];
    vector<pii> t;
    set<int> job;
    int j[k] = {0};
    for(int i=0; i<n; i++)
    {
        cin >> a[i];
        job.insert(a[i]);
        j[a[i]-1] ++;
    }
    for(int j=0; j<n; j++) 
    {
        cin >> b[j];
        t.pb(make_pair(b[j],a[j]));
    }
    int q = job.size();
    if(q == k) 
    {
        cout << "0\n";
        return;
    }
    sort(t.begin(), t.end());
    ll ans = 0;

    for(int i=0; i<n; i++)
    {
        if(q < k)
        {
            if(j[t[i].S-1] > 1)
            {
                ans += t[i].F;
                j[t[i].S-1] --;
                q ++;
            }
        }
        else 
        {
            cout << ans << endl;
            return;
        }
    }
}
int main()
{
    int t;
    t = 1;
    while(t--) solve();
}