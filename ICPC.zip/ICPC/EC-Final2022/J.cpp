#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define pii pair<int,int>
using namespace std;
const ll N = 1e9;
const ll mod = 998244353;
ll sum = 0;
void solve()
{
   int n; 
   cin >> n; 
   vector<int> leaf(n,0);
   int pow[n] = {0};
   pii arr[n];
   int a,b;
   for(int i=0; i<n-1; i++)
   {
    cin >> a >> b;
    arr[i] = make_pair(a-1,b-1);
    pow[a-1] ++;
    pow[b-1] ++;
   }

   for(int i=0; i<n-1; i++)
   {
    if(pow[arr[i].first] == 1) 
    {
        leaf[arr[i].second] ++;
    }
    else if(pow[arr[i].second] == 1)
    {
        leaf[arr[i].first] ++;
    }
   }

   sort(leaf.rbegin(), leaf.rend());

   if(leaf[0] == n-1) 
   {
    cout << "-1\n";
    return;
   }
   ll ans = 0;
   for(int i=0; i<n; i++) ans += leaf[i];
   
    int res = ((ans + 1) / 2 >= leaf[0]) ? (ans + 1) / 2 : leaf[0];
    cout << res << "\n";

}
int main()
{
   int t;
   cin >> t;
   while(t--) solve();
}