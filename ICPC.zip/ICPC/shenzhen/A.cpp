#include<bits/stdc++.h>
#define ll long long 
#define pii pair<int,int>
#define mk make_pair
#define F first
#define S second
#define pb push_back
using namespace std;
int const N = 2e5 + 2;
int ans = 0;
vector<pii> res;
int n;
vector<int> a(n,0);
void div(vector<int> b, int l ,int r)
{
    if(r <= l)
    {
        ans ++;
        return;
    }
    for(int i=(r+l)/2; i<r; i++)
    {
        if(a[i] < b[i]) 
        {
            res.pb(mk(2,i + 1));
            a[i] ++;
        }
    }
    while(a[(r+l)/2] < b[(r+l)/2])
    {
        res.pb(mk(1,a[(r+l)/2 + 1]));
        for(int i=(r+l)/2; i<r; i++)
        {
            a[i] += 1;
        }
        
    }
    div(b, (r+l)/2 + 1, r);
    div(b, l, (r+l-1)/2);
}
void solve()
{
    cin >> n;
    vector<int> b(n);
    for(int i=0; i<n; i++)
    {
        cin >> b[i];
    }
    div(b, 0, n);
    cout << res.size() << endl;
    for(int i=0; i<res.size(); i++)
    {
        cout << res[i].F << " " << res[i].S << endl;
    }
}
int main()
{    
    int t;
    // cin >> t;
    t = 1;
    while(t--) solve();
}